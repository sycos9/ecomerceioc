package randomecommerce.randomecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RandomecommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RandomecommerceApplication.class, args);
	}

}

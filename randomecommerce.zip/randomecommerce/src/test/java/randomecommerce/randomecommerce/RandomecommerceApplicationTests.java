package randomecommerce.randomecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RandomecommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
